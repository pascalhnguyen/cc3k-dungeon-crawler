#include "dragon.h"
#include "gold.h"

Dragon::Dragon(): Enemy{'D', 0, 150, 20, 20, true} {}

