#include "dwarf.h"

Dwarf::Dwarf(): Enemy{'W', 7, 100, 20, 30, true} {}
