#include "elf.h"
#include "gold.h"

Elf::Elf(): Enemy{'E', 7, 140, 30, 10, true} {}

