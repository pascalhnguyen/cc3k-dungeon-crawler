#ifndef _ELF_H_
#define _ELF_H_

#include "enemy.h"

class Elf: public Enemy{

 public:
  Elf();
};

#endif
