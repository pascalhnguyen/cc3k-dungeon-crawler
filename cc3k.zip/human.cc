#include "human.h"

Human::Human(): Enemy{'H', 8, 140, 20, 20, true} {}
