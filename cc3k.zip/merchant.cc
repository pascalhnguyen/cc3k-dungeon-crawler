#include "merchant.h"
#include "gold.h"

Merchant::Merchant(): Enemy{'M', 8, 30, 70, 5, false} {}
