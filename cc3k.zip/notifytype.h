#ifndef _NOTIFYTYPE_H_
#define _NOTIFYTYPE_H_

enum class NotifyType{ moveFrom, moveTo ,remove, pingGuardian };

#endif
