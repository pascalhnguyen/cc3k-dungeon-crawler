#include "orc.h"
#include "gold.h"

Orc::Orc(): Enemy{'O', 6, 180, 30, 25, true} {}

