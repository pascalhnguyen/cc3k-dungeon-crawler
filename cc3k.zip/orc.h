#ifndef _ORC_H_
#define _ORC_H_

#include "enemy.h"

class Orc: public Enemy{

 public:
  Orc();
};

#endif
